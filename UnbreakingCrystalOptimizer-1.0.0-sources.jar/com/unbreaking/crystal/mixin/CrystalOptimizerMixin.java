package com.unbreaking.crystal.mixin;

import net.minecraft.class_1802;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_310.class)
public abstract class CrystalOptimizerMixin {
    @Shadow public int itemUseCooldown;

    @Inject(method = "handleInputEvents", at = @At("HEAD"))
    private void onHandleInputEvents(CallbackInfo ci) {
        class_310 client = (class_310) (Object) this;
        if (client.field_1724 == null) return;

        // تسريع الكول داون بشكل آمن ورسمي
        if (client.field_1724.method_6047().method_31574(class_1802.field_8301) || client.field_1724.method_6079().method_31574(class_1802.field_8301)) {
            if (this.itemUseCooldown > 1) this.itemUseCooldown = 1;
        } else if (client.field_1724.method_6047().method_31574(class_1802.field_8281) || client.field_1724.method_6079().method_31574(class_1802.field_8281)) {
            if (this.itemUseCooldown > 2) this.itemUseCooldown = 2;
        }
    }
}