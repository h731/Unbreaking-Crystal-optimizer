package com.unbreaking.crystal.mixin;

import com.unbreaking.crystal.config.CrystalConfig;
import net.minecraft.class_1511;
import net.minecraft.class_4604;
import net.minecraft.class_892;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@SuppressWarnings("unused")
@Mixin(class_892.class)
public class EndCrystalRenderOptimizerMixin {

    /**
     * إلغاء رسم الكريستال المدمر أو الجديد لتوفير الأداء (مرتبط بالإعدادات)
     */
    @Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true, require = 0)
    private void onShouldRender(class_1511 entity, class_4604 frustum, double x, double y, double z, CallbackInfoReturnable<Boolean> cir) {
        if (CrystalConfig.optimizeCrystalRendering) {
            if (entity == null || entity.method_31481() || entity.field_6012 <= 1) {
                cir.setReturnValue(false);
            }
        }
    }

    /**
     * إيقاف الاهتزاز الرأسي للكريستال (مرتبط بالإعدادات)
     */
    @Inject(method = "getYOffset", at = @At("HEAD"), cancellable = true, require = 0)
    private static void onGetYOffset(float tickDelta, CallbackInfoReturnable<Float> cir) {
        if (CrystalConfig.disableCrystalMovement) {
            cir.setReturnValue(0.0f);
        }
    }
}