package com.unbreaking.crystal.mixin;

import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_759;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_759.class)
public abstract class HeldItemRendererMixin {
    @Shadow private float equipProgressMainHand, prevEquipProgressMainHand;
    @Shadow private float equipProgressOffHand, prevEquipProgressOffHand;
    @Shadow private class_1799 mainHand, offHand;

    @Inject(method = "updateHeldItems", at = @At("TAIL"))
    private void onUpdateHeldItems(CallbackInfo ci) {
        if (mainHand.method_31574(class_1802.field_8301) || mainHand.method_31574(class_1802.field_8281)) {
            equipProgressMainHand = prevEquipProgressMainHand = 1.0f;
        }
        if (offHand.method_31574(class_1802.field_8301) || offHand.method_31574(class_1802.field_8281)) {
            equipProgressOffHand = prevEquipProgressOffHand = 1.0f;
        }
    }
}