package com.unbreaking.crystal.mixin;

import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_759;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_759.class)
public abstract class HeldItemRendererMixin {

    @Shadow private class_1799 mainHand;
    @Shadow private class_1799 offHand;
    @Shadow private float equipProgressMainHand;
    @Shadow private float prevEquipProgressMainHand;
    @Shadow private float equipProgressOffHand;
    @Shadow private float prevEquipProgressOffHand;

    /**
     * إلغاء أنيميشن التبديل اللحظي للكريستال والأوبسيديان فقط
     */
    @Inject(method = "updateHeldItems", at = @At("TAIL"))
    private void onUpdateHeldItems(CallbackInfo ci) {
        if (isPvpItem(this.mainHand)) {
            this.equipProgressMainHand = 1.0f;
            this.prevEquipProgressMainHand = 1.0f;
        }
        if (isPvpItem(this.offHand)) {
            this.equipProgressOffHand = 1.0f;
            this.prevEquipProgressOffHand = 1.0f;
        }
    }

    private boolean isPvpItem(class_1799 stack) {
        return stack.method_31574(class_1802.field_8301) || stack.method_31574(class_1802.field_8281);
    }
}