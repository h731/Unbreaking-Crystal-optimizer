package com.unbreaking.crystal.mixin;

import com.unbreaking.crystal.config.CrystalConfig;
import net.minecraft.class_1511;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@SuppressWarnings("unused")
@Mixin(class_1511.class)
public class EndCrystalEntityMixin {

    @Shadow public int endCrystalAge;

    /**
     * تجميد دوران الكريستال وثباته في مكانه (مرتبط بالإعدادات)
     */
    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        if (CrystalConfig.disableCrystalMovement) {
            this.endCrystalAge = 0;
        }
    }
}