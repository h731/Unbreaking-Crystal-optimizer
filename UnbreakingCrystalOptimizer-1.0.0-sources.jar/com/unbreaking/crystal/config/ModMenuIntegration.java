package com.unbreaking.crystal.config;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;
import me.shedaniel.clothconfig2.api.ConfigBuilder;
import me.shedaniel.clothconfig2.api.ConfigCategory;
import me.shedaniel.clothconfig2.api.ConfigEntryBuilder;
import net.minecraft.class_2561;

public class ModMenuIntegration implements ModMenuApi {
    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return parent -> {
            ConfigBuilder builder = ConfigBuilder.create()
                    .setParentScreen(parent)
                    .setTitle(class_2561.method_43470("Unbreaking Crystal Optimizer"));

            // حفظ الإعدادات تلقائياً عند الضغط على Save
            builder.setSavingRunnable(CrystalConfig::save);

            ConfigCategory general = builder.getOrCreateCategory(class_2561.method_43470("General"));
            ConfigEntryBuilder entryBuilder = builder.entryBuilder();

            // خيار تفعيل/إلغاء تفعيل الـ Anchor Optimizer
            general.addEntry(entryBuilder.startBooleanToggle(class_2561.method_43470("Anchor Optimizer"), CrystalConfig.enableAnchorOptimizer)
                    .setDefaultValue(true)
                    .setSaveConsumer(newValue -> CrystalConfig.enableAnchorOptimizer = newValue)
                    .build());

            // خيار تفعيل/إلغاء تفعيل حركة الكريستال
            general.addEntry(entryBuilder.startBooleanToggle(class_2561.method_43470("Disable Crystal Movement"), CrystalConfig.disableCrystalMovement)
                    .setDefaultValue(true)
                    .setSaveConsumer(newValue -> CrystalConfig.disableCrystalMovement = newValue)
                    .build());

            // خيار تفعيل/إلغاء تفعيل رسم الكريستال
            general.addEntry(entryBuilder.startBooleanToggle(class_2561.method_43470("Optimize Crystal Rendering"), CrystalConfig.optimizeCrystalRendering)
                    .setDefaultValue(true)
                    .setSaveConsumer(newValue -> CrystalConfig.optimizeCrystalRendering = newValue)
                    .build());

            // خيار تفعيل/إلغاء تفعيل تحسين الضرب
            general.addEntry(entryBuilder.startBooleanToggle(class_2561.method_43470("Enable Attack Optimizer"), CrystalConfig.enableAttackOptimizer)
                    .setDefaultValue(true)
                    .setSaveConsumer(newValue -> CrystalConfig.enableAttackOptimizer = newValue)
                    .build());

            return builder.build();
        };
    }
}