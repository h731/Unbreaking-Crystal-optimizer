package com.unbreaking.crystal.mixin;

import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1802;
import net.minecraft.class_239;
import net.minecraft.class_2824;
import net.minecraft.class_310;
import net.minecraft.class_3966;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_310.class)
public abstract class CrystalOptimizerMixin {

    @Shadow
    public int itemUseCooldown;

    @Shadow
    public class_239 crosshairTarget;

    // تأخير طبيعي وسريع للأوبسيديان فقط (2 تيك)
    private static final int OBSIDIAN_DELAY = 2;

    /**
     * 1. الوضع السريع للكريستال والأوبسيديان
     */
    @Inject(method = "handleInputEvents", at = @At("HEAD"))
    private void onHandleInputEvents(CallbackInfo ci) {
        class_310 client = (class_310) (Object) this;
        if (client.field_1724 == null) return;

        // أ) الكريستال: وضع سريع ولحظي بالكامل (0-tick)
        boolean isHoldingCrystal = client.field_1724.method_6047().method_31574(class_1802.field_8301)
                || client.field_1724.method_6079().method_31574(class_1802.field_8301);

        if (isHoldingCrystal) {
            if (this.itemUseCooldown > 0) {
                this.itemUseCooldown = 0;
            }
            return;
        }

        // ب) الأوبسيديان: وضع سريع بلمسة طبيعية (2-ticks)
        boolean isHoldingObsidian = client.field_1724.method_6047().method_31574(class_1802.field_8281)
                || client.field_1724.method_6079().method_31574(class_1802.field_8281);

        if (isHoldingObsidian && this.itemUseCooldown > OBSIDIAN_DELAY) {
            this.itemUseCooldown = OBSIDIAN_DELAY;
        }
    }

    /**
     * 2. الكسر السريع للكريستال ومنع الـ Ghosting
     */
    @Inject(method = "doAttack", at = @At("HEAD"), cancellable = true)
    private void onDoAttack(CallbackInfoReturnable<Boolean> cir) {
        class_310 client = (class_310) (Object) this;
        if (client.field_1724 == null || client.field_1687 == null) return;

        if (this.crosshairTarget != null && this.crosshairTarget.method_17783() == class_239.class_240.field_1331) {
            class_1297 target = ((class_3966) this.crosshairTarget).method_17782();

            if (target instanceof class_1511 crystal) {
                // إرسال حزمة الهجوم مباشرة
                client.field_1724.field_3944.method_52787(
                        class_2824.method_34206(crystal, client.field_1724.method_5715())
                );

                client.field_1724.method_6104(class_1268.field_5808);

                // Anti-Ghosting: تدمير الكريستال محلياً فوراً
                crystal.method_31472();

                cir.setReturnValue(true);
            }
        }
    }
}