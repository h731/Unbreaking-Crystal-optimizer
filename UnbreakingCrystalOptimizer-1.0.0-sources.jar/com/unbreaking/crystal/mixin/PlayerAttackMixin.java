package com.unbreaking.crystal.mixin;

import com.unbreaking.crystal.config.CrystalConfig;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@SuppressWarnings("unused")
@Mixin(class_1657.class)
public abstract class PlayerAttackMixin {

    @Shadow public abstract void resetLastAttackedTicks();

    @Inject(method = "attack", at = @At("HEAD"))
    private void onAttack(class_1297 target, CallbackInfo ci) {
        // التحقق من تفعيل الميزة من الإعدادات
        if (!CrystalConfig.enableAttackOptimizer) return;

        // التحقق من أن اللاعب هو اللاعب المحلي لتطبيق تحسين الأداء
        if ((Object) this instanceof class_746 player) {
            if (target instanceof class_1309) {
                // تحسين الأداء الحقيقي: إجبار اللعبة على إعادة ضبط العداد المحلي فوراً
                // لضمان عدم تأخير أو تعليق تسجيل أي ضربة (Zero Attack Lag)
                this.resetLastAttackedTicks();
            }
        }
    }
}