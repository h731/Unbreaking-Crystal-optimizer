package com.unbreaking.crystal.mixin;

import com.unbreaking.crystal.config.CrystalConfig;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3965;
import net.minecraft.class_4969;
import net.minecraft.class_636;
import net.minecraft.class_638;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@SuppressWarnings("unused")
@Mixin(class_636.class)
public class AnchorOptimizerMixin {

    @Inject(method = "interactBlock", at = @At("RETURN"))
    private void onAnchorInteract(class_746 player, class_1268 hand, class_3965 hitResult, CallbackInfoReturnable<class_1269> cir) {
        if (!CrystalConfig.enableAnchorOptimizer) return;

        class_310 client = class_310.method_1551();
        class_638 world = client.field_1687;

        if (world != null && !client.method_1542()) {
            class_2338 pos = hitResult.method_17777();
            class_2680 state = world.method_8320(pos);

            if (state.method_27852(class_2246.field_23152)) {
                boolean holdingGlowstoneMain = player.method_6047().method_31574(class_1802.field_8801);
                boolean holdingGlowstoneOff = player.method_6079().method_31574(class_1802.field_8801);
                boolean isSneaking = player.method_5715();

                if (!holdingGlowstoneMain && !holdingGlowstoneOff && !isSneaking) {
                    Integer charges = state.method_11654(class_4969.field_23153);

                    if (charges != null && charges > 0) {
                        double cx = pos.method_10263() + 0.5;
                        double cy = pos.method_10264() + 0.5;
                        double cz = pos.method_10260() + 0.5;

                        // تشغيل المؤثرات وصوت الانفجار فوراً (مع الحفاظ على البلوكة ليعمل الـ Air Anchor)
                        world.method_8406(class_2398.field_11236, cx, cy, cz, 0.0, 0.0, 0.0);
                        world.method_8406(class_2398.field_11221, cx, cy, cz, 0.0, 0.0, 0.0);

                        // التوقيع الصحيح بـ 8 معاملات للـ ClientWorld
                        world.method_8486(cx, cy, cz, class_3417.field_15152.comp_349(), class_3419.field_15245, 4.0F, 0.7F, false);
                    }
                }
            }
        }
    }
}